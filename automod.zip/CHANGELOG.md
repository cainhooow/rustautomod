# Change Log

## [released]

### 1.0.8

- **Hide/Show mod.rs files**: Quickly toggle the visibility of all mod.rs files via the Command Palette (`Hidden/Show Rust Modules Files`)
